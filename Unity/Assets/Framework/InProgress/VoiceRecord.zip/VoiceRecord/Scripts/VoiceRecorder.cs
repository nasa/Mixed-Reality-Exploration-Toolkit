﻿/*
 * 
 * This file records and saves an audio file via  button push
 * 
 */ 

using UnityEngine;

public class VoiceRecorder : MonoBehaviour
{

    AudioClip recording;
    bool isRecording = false;
    AudioSource audioSource;
    private float startRecordingTime;

    //update method to call startRecord or stopRecord method when the space bar is pressed
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isRecording)
            {
                stopRecording();
                isRecording = false;
                Debug.Log("[VoiceRecorder] Recording stopped");

            }
            else
            {
                startRecording();
                isRecording = true;
                Debug.Log("[VoiceRecorder] Recording started");

            }
        }
    }

    private void Start()
    {
        audioSource = GetComponent<AudioSource>(); //get the audio source component attached to the same GameObject this script is
    }

    //method to stop recording - can set a custom file name if desired. The audio file is saved to the Assets folder
    public void stopRecording(string fileName = "audioFile")
    {

        Microphone.End(null);
        AudioClip recordingNew = AudioClip.Create(recording.name, (int)((Time.time - startRecordingTime) * recording.frequency), recording.channels, recording.frequency, false);
        float[] data = new float[(int)((Time.time - startRecordingTime) * recording.frequency)];
        recording.GetData(data, 0);
        recording.SetData(data, 0);
        audioSource.clip = recording;
        SavWav.Save(fileName, audioSource.clip);

    }

    //method to start recording
    public void startRecording()
    {

        recording = Microphone.Start(null, false, 300, 44100);
        startRecordingTime = Time.time;

    }

}
