﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class NotebookPopulater : MonoBehaviour
{
    public GameObject noteb;
    public GameObject multimediaNotePrefab;
    public GameObject notebookPrefab;
    public GameObject firstElement;
    public GameObject currentActiveNote;
    public GameObject mediaGallery;
    public GameObject saveMenu;
    public GameObject exportMenu;
    public GameObject loadMenu;
    public GameObject multimediaNoteReferenceForLoading;
    public Transform parent;
    public InputField titleInputField;
    public ScrollListManager notebookprojectListDisplay;
    public TextAsset jsonFile;
    public MultimediaNote multimediaNote;
    public GalleryManager galleryManager;
    public CopyPaste copyPaste;
    public string filePath;
    public int i = 1;

    private NoteCollection nc = new NoteCollection();
    private TMPro.TMP_InputField titleInputFieldTMP;
    private TMPro.TextMeshProUGUI selectedText;
    private TMPro.TMP_InputField selectedInputField;
    private int currentSelection = -1;
    private List<GameObject> notebook = new List<GameObject>();

    [Serializable]
    public class NotebookItem
    {
        public string itemKey;
        public string itemValue;
    }

    [Serializable]
    public class NotebookNote
    {
        public List<NotebookItem> notebookItems = new List<NotebookItem>();
    }

    [Serializable]
    public class NoteCollection
    {
        public List<NotebookNote> notebook = new List<NotebookNote>();
    }

    void Start()
    {
        notebookprojectListDisplay.SetTitle("Notes");
    }

    public void setTitle(string title)
    {
        titleInputFieldTMP.text = title;
    }

    public void openMenu(GameObject menu)
    {
        if (!menu.activeSelf)
        {
            menu.SetActive(true);
        }
        else
        {
            menu.SetActive(false);
        }
    }

    public void setFilePath(GameObject textField)
    {
        filePath = textField.GetComponent<Text>().text;
        Debug.Log(filePath);
        saveNotebook(filePath);

    }

    public void setFilePathToLoad(GameObject textField)
    {
        loadNotebook(textField.GetComponent<Text>().text);
    }

    private void addNewElementToScrollList(GameObject multimediaNote)
    {     
        GameObject newScrollListItem = notebookprojectListDisplay.AddAndGetScrollListItem("untitled_" + i.ToString(), true);
        newScrollListItem.GetComponent<MultimediaNote>().setID(i);
        i++;
    }

    private void SetActiveSelectionListID(string note)
    {
        noteb.SetActive(true);
    }

    public void setActiveSelectionButtonID(MultimediaNote multimediaNote)
    {
        int buttonID = buttonID = multimediaNote.GetComponent<MultimediaNote>().getID();
        Debug.Log("Button ID: " + buttonID.ToString());

        if(buttonID == 0) //add note to note menu
        {

            //the following code ensures correct position of the new note and creates a new note game object
            Vector3 position = new Vector3(0f, 0f, 0f); //maybe this is not needed?
            Quaternion rotation = new Quaternion(0f, 0f, 0f, 0f);
            GameObject newMultimediaNote = multimediaNote.createMultimediaNote(parent, position, rotation);
            multimediaNoteReferenceForLoading = newMultimediaNote;
            Vector3 newPosition = new Vector3(-3f, -32f, 0f);
            Vector3 scale = new Vector3(0.67f, 1.23f, 1f);
            
            if(!newMultimediaNote.GetComponentInChildren<DynamicTMPTextResizer>())
            {
                Debug.Log("[NotebookPopular] WARNING: Could not find notebook populator script in children");
            } else
            {
                newMultimediaNote.GetComponentInChildren<DynamicTMPTextResizer>().notebookPopulater = gameObject.GetComponent<NotebookPopulater>();
                Debug.Log("scipt set");
            }

            currentActiveNote.SetActive(false);
            newMultimediaNote.SetActive(true);
            newMultimediaNote.transform.localPosition = newPosition;
            newMultimediaNote.transform.localScale = scale;
            notebook.Add(newMultimediaNote);
            currentActiveNote = newMultimediaNote;
            addNewElementToScrollList(newMultimediaNote);
            MultimediaNoteManager multimediaNoteManager = newMultimediaNote.GetComponent<MultimediaNoteManager>();
            GalleryManager[] galleryManagerArray = galleryManager.gameObject.GetComponentsInChildren<GalleryManager>();

            foreach(GalleryManager galleryManagerInChild in galleryManagerArray)
            {
                galleryManagerInChild.setMultimediaNoteManager(multimediaNoteManager);
            }

        } else //set clicked note active and all other disabled
        {
            currentActiveNote.SetActive(false);
            notebook[buttonID - 1].SetActive(true);
            currentActiveNote = notebook[buttonID - 1];
        }

        Debug.Log("note set to active");
    }

    private void SetActiveSelection(int listID)
    {
        currentSelection = listID;
        notebookprojectListDisplay.HighlightItem(listID);
    }

    public void saveNotebook(string filePathSuffix)
    {
        createObjectsForSerialization(noteb.transform);
        string filePathPrefix = @"C:\Users\cmtrombl\Downloads\MRET_Core\Unity\Assets\";
        string filePathFull = filePathPrefix + filePathSuffix + ".json";
        Debug.Log(filePathFull);
        string jsonString = JsonConvert.SerializeObject(nc, Formatting.Indented);
        File.WriteAllText(filePathFull, jsonString);
    }

    void createObjectsForSerialization(Transform transform)
    {
        if(transform.name.ToString() != "Gallery")
        {
            foreach (Transform child in transform)
            {

                if (child.name.Contains("MultimediaNote"))
                {
                    Debug.Log(child.name);
                    NotebookNote newNote = new NotebookNote();
                    nc.notebook.Add(newNote);
                }

                if (nc.notebook.Count != 0)
                {

                    NotebookNote noteToModify = nc.notebook[nc.notebook.Count - 1];

                    if (child.name == "TitlePanel")
                    {
                        if (child.GetComponentInChildren<TMPro.TMP_InputField>())
                        {
                            string titleText = child.GetComponentInChildren<TMPro.TMP_InputField>().text;
                            Debug.Log(titleText);
                            NotebookItem newItem = new NotebookItem();
                            newItem.itemKey = "Title";
                            newItem.itemValue = titleText;
                            noteToModify.notebookItems.Add(newItem);
                        }
                    }

                    if (child.name.Contains("TextContainer"))
                    {
                        Debug.Log(child.GetComponentInChildren<TMPro.TMP_InputField>().text);
                        string text = child.GetComponentInChildren<TMPro.TMP_InputField>().text;
                        NotebookItem newItem = new NotebookItem();
                        newItem.itemKey = "Text";
                        newItem.itemValue = text;
                        noteToModify.notebookItems.Add(newItem);
                    }

                    if (child.name.Contains("ImageContainer"))
                    {
                        Debug.Log(child.GetComponent<ImageContainer>().getImagePath());
                        string imagePath = child.GetComponent<ImageContainer>().getImagePath();
                        NotebookItem newItem = new NotebookItem();
                        newItem.itemKey = "Image";
                        newItem.itemValue = imagePath;
                        noteToModify.notebookItems.Add(newItem);
                    }

                    if (child.name.Contains("VideoContainer"))
                    {
                        Debug.Log(child.GetComponent<RawImage>().texture.name);
                    }
                }

                createObjectsForSerialization(child);

            }
        }
    }

    public void loadNotebook(string filePathSuffix)
    {
        string filePathPrefix = @"C:\Users\cmtrombl\Downloads\MRET_Core\Unity\Assets\";
        string filePathFinal = filePathPrefix + filePathSuffix + ".json";
        GameObject instantiatedNotebook = loadNotebookObjects(filePathFinal);
    }

    public GameObject loadNotebookObjects(string filePathSuffix)
    {
        int buttonID = 0;
        GameObject newNotebook = Instantiate(notebookPrefab); //creates the notebook
        NotebookPopulater notebookPopulater = newNotebook.GetComponentInChildren<NotebookPopulater>();
        MultimediaNote multimediaNote = notebookPopulater.gameObject.GetComponentInChildren<MultimediaNote>();
        string filePathPrefix = @"C:\Users\cmtrombl\Downloads\MRET_Core\Unity\Assets\";
        string filePathFinal = filePathPrefix + filePathSuffix + ".json";
        string text = File.ReadAllText(filePath);
        NoteCollection notebookToLoad = JsonConvert.DeserializeObject<NoteCollection>(text);

        foreach(NotebookNote note in notebookToLoad.notebook)
        {

            notebookPopulater.setActiveSelectionButtonID(multimediaNote); //creates a new note
            GameObject instantiatedMultimediaNote = multimediaNoteReferenceForLoading;
            MultimediaNoteManager instantiatedMultimediaNoteManager = instantiatedMultimediaNote.GetComponent<MultimediaNoteManager>();

            foreach (NotebookItem element in note.notebookItems)
            {

                switch(element.itemKey)
                {
                    case "Title": 
                        TMPro.TMP_InputField[] titleTextContainers = instantiatedMultimediaNote.GetComponentsInChildren<TMPro.TMP_InputField>();
                        TMPro.TMP_InputField titleField = titleTextContainers[titleTextContainers.Length - 1]; //since order is preserved
                        titleField.text = element.itemValue;
                        break;
                    case "Image":
                        string imagePath = element.itemValue;
                        byte[] imageBytes = File.ReadAllBytes(imagePath);
                        Texture2D imageTexture = new Texture2D(2, 2); //(2,2) is arbitrary since it will dynamically resize
                        bool isLoaded = imageTexture.LoadImage(imageBytes);
                        instantiatedMultimediaNoteManager.insertImage(imageTexture, imagePath);
                        break;
                    case "Video":

                        break;
                    case "Text":
                        TMPro.TMP_InputField[] textContainers = instantiatedMultimediaNote.GetComponentsInChildren<TMPro.TMP_InputField>();
                        TMPro.TMP_InputField lastInputField = textContainers[textContainers.Length - 1];
                        lastInputField.text = element.itemValue;
                        break;

                }
            }

        }

        return newNotebook;
    }



    public void strikethrough()
    {
        string inputFieldRichText = selectedInputField.text;
        int caretStartingIndex = selectedInputField.selectionStringAnchorPosition;
        int caretEndingIndex = selectedInputField.selectionStringFocusPosition;
        int length = Math.Abs(caretStartingIndex - caretEndingIndex);
        Debug.Log(inputFieldRichText);
        Debug.Log(caretStartingIndex);
        Debug.Log(caretEndingIndex);

        if(caretStartingIndex > caretEndingIndex)
        {
            int tempToSwap = caretEndingIndex;
            caretEndingIndex = caretStartingIndex;
            caretStartingIndex = tempToSwap;
        }

        if(caretStartingIndex == 0)
        {
            //do case spex logic
        }
        
        string highlightedString = inputFieldRichText.Substring(caretStartingIndex, length);
        string pre = inputFieldRichText.Substring(0, caretStartingIndex);
        string post; //to do
        Debug.Log(highlightedString);
        string newText = pre + "<s>" + highlightedString + "</s>";
        selectedInputField.text = newText;
        Debug.Log("new text set");
        selectedInputField.ForceLabelUpdate(); //try without this when final testing
    }

    public void addMedia()
    {
        if(!mediaGallery.activeSelf)
        {
            mediaGallery.SetActive(true);
        } else
        {
            mediaGallery.SetActive(false);
        }
    }

    public void addBulletPoints()
    {
        string inputFieldRichText = selectedInputField.text;
        selectedInputField.text = inputFieldRichText + "\n \u2022";
    }

    public void setSelectedText(TMPro.TMP_InputField selectedInputField)
    {
        this.selectedInputField = selectedInputField;
    }

    public TMPro.TextMeshProUGUI getSelectedText()
    {
        return selectedText;
    }

    //copy paste etc

    public void speechToText()
    {

    }

    public void exportNoteToWordDocument()
    {

    }

    public void deleteNote()
    {

    }

    private void OnDisable()
    {

    }

}