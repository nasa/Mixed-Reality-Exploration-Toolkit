﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TitleChangeListener : MonoBehaviour
{

    public GameObject correspondingScrollListGameObject;
    private Text noteScrollListText;
    private InputField multimediaNoteTitleInputField;

    // Start is called before the first frame update
    void Start()
    {
        noteScrollListText = correspondingScrollListGameObject.GetComponentInChildren<Text>();

        multimediaNoteTitleInputField.onValueChanged.AddListener(delegate { titleTextChanged(); });

        if(!noteScrollListText)
        {
            Debug.Log("[TitleChangeListener] WARNING: Could not field text field in children");
        }

        if(!multimediaNoteTitleInputField)
        {
            Debug.Log("[TitleChangeListener] WARNING: Could not input field - is it set in the editor?");
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void titleTextChanged()
    {
        string newTitle = multimediaNoteTitleInputField.text;
        Debug.Log(newTitle);
        noteScrollListText.text = newTitle;
    }

}
