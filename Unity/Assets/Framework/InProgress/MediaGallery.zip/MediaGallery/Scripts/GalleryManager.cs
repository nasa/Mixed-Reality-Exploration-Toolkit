﻿/*
 * 
 * This file handles populating the gallery with images and videos from a predefined directory path
 * 
 */
 
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class GalleryManager : MonoBehaviour
{

    public GameObject imageContainer;
    public MultimediaNoteManager multimediaNoteManager;
    public GameObject videoContainer;

    //populate the gallery on start
    void Start()
    {
        multimediaNoteManager = GameObject.Find("MultimediaNote").GetComponent<MultimediaNoteManager>();
        Populate();
    }

    //method that populates the gridview of the gallery prefab with images and videos
    void Populate()
    {

        GameObject container;
        DirectoryInfo mediaDirectory = new DirectoryInfo("C:\\Users\\cmtrombl\\Downloads\\MRET_Core\\Unity\\Assets\\Framework\\Components\\Multimedia Notes\\TestMedia");
        FileInfo[] images = mediaDirectory.GetFiles("*.png");
        FileInfo[] videos = mediaDirectory.GetFiles("*.mp4");

        foreach (FileInfo imagePath in images)
        {
            container = Instantiate(imageContainer, transform);
            byte[] imageBytes = File.ReadAllBytes(imagePath.ToString());
            Texture2D imageTexture = new Texture2D(2, 2);
            bool isLoaded = imageTexture.LoadImage(imageBytes);

            if (isLoaded)
            {
                container.GetComponent<RawImage>().texture = imageTexture;
            }

        }

        foreach (FileInfo videoPath in videos)
        {

            container = Instantiate(videoContainer, transform);
            container.GetComponent<VideoPlayer>().url = videoPath.ToString();
           
        }

    }

    //each media container contains a button script and when the a click is registered this method is called
    //to insert the image/video into the multimedia note
    public void insertToNote()
    {

        multimediaNoteManager.insertImage(gameObject.GetComponent<RawImage>().texture);

    }

}