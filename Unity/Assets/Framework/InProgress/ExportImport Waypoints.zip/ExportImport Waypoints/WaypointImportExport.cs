﻿/*
* This file contains methods that take in a dictionary with the robot pose in joint space or cartesian space and saves them to a JSON file
* or vice versa
* 
*/
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class WaypointImportExport : MonoBehaviour
{

    private void Start()
    {
        //to test the methods
        Dictionary<string, float> sixDOFPoseTest = new Dictionary<string, float>();
        sixDOFPoseTest.Add("J0", 122.1f);
        sixDOFPoseTest.Add("J1", 123.1f);
        sixDOFPoseTest.Add("J2", 124.1f);
        sixDOFPoseTest.Add("J3", 125.1f);
        sixDOFPoseTest.Add("J4", 126.1f);
        sixDOFPoseTest.Add("J5", 127.1f);
        exportWaypoints(sixDOFPoseTest);

        Dictionary<string, string> testDict = new Dictionary<string, string>();
        testDict = importWaypoints();
        Debug.Log(testDict);
    }

    public Dictionary<string, string> importWaypoints(string filePath = @"C:\Users\cmtrombl\Downloads\MRET_Core\Unity\Assets\test.json")
    {

        Dictionary<string, string> robotPose = new Dictionary<string, string>();
        string text = File.ReadAllText(filePath);
        robotPose = JsonConvert.DeserializeObject<Dictionary<string, string>>(text);

        return robotPose;
    }

    public void exportWaypoints(Dictionary<string, float> robotPose, string filePath = @"C:\Users\cmtrombl\Downloads\MRET_Core\Unity\Assets\test.json")
    {
        string jsonString = JsonConvert.SerializeObject(robotPose);                                                              
        File.WriteAllText(filePath, jsonString);
    }

}
